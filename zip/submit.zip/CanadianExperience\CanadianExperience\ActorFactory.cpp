/**
 * \file ActorFactory.cpp
 *
 * \author Elizabeth Stevens
 */

#include "pch.h"
#include "ActorFactory.h"

/** Destructor */
CActorFactory::~CActorFactory()
{
}
